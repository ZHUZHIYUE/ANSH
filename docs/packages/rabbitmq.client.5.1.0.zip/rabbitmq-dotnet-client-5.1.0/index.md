# RabbitMQ .NET Client

Links:

* [RabbitMQ .NET Client](http://www.rabbitmq.com/dotnet.html)
* [RabbitMQ .NET Client API Guide](http://www.rabbitmq.com/dotnet-api-guide.html)
* [API Reference](api/RabbitMQ.Client.html)
* [Tutorials](http://www.rabbitmq.com/tutorials/tutorial-one-dotnet.html)
